<footer class="rodape">
  <p>Termo/TSI. Todos os Direitos Reservados.</p>
</footer>

<style>
  .rodape {
      width: 100%;
      padding: 6.5px;
      font-size: 14px;
      text-align: center;
      background: #872d62;
      color: var(--light-color);
  }
</style>